
- **`sudo -i`**  

- **`fdisk -l /dev/sda`**  

- **`mkdir -p /mnt/recuperar`**  

- **`mount -t auto /dev/sda1 /mnt/recuperar`**  

- **`mount --bind /dev /mnt/recuperar/dev`**  

- **`mount --bind /proc /mnt/recuperar/proc`**  

- **`mount --bind /sys /mnt/recuperar/sys`**  

- **`chroot /mnt/recuperar /bin/bash`**  

- **`passwd tu_usuario`**  

- **`exit`**  

- **`umount /mnt/recuperar/dev`**, **`umount /mnt/recuperar/proc`**, **`umount /mnt/recuperar/sys`**, **`umount /mnt/recuperar`**  

- **`poweroff`**  
